some data2
